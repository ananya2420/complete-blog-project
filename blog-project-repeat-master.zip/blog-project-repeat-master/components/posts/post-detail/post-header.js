import Image from "next/image";

function PostHeader({ title, image }) {
  return (
    <header className="text-center mb-8">
      <h1 className="text-3xl sm:text-4xl font-extrabold text-gray-900 mb-6">
        {title}
      </h1>

      <div className="relative w-full max-w-3xl h-64 mx-auto rounded-xl overflow-hidden shadow-md">
        <Image
          src={image}
          alt={title}
          fill
          className="object-cover"
          sizes="(max-width: 768px) 100vw, 768px"
        />
      </div>
    </header>
  );
}

export default PostHeader;
