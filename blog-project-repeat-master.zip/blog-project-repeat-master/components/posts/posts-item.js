import Image from "next/image";
import Link from "next/link";

function PostItem(props) {
  const { title, image, excerpt, date, slug } = props.post;

  const formattedDate = new Date(date).toLocaleDateString("en-US", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  const imagePath = `/images/posts/${image}`;
  const linkPath = `/posts/${slug}`;

  return (
    <li className="overflow-hidden rounded-2xl bg-white shadow-md transition hover:shadow-lg">
      <Link href={linkPath} className="flex flex-col sm:flex-row">
        {/* Image (Left Side) */}
        <div className="relative w-full sm:w-1/3 h-60 sm:h-52">
          <Image
            src={imagePath}
            alt={title}
            width={300}
            height={200}
            layout="responsive"
            className="object-cover"
            sizes="(max-width: 640px) 100vw, 33vw"
          />
        </div>

        {/* Text Content (Right Side) */}
        <div className="flex flex-col justify-center p-4 sm:w-2/3">
          <h3 className="text-xl font-bold text-gray-800 mb-1">{title}</h3>
          <time className="text-sm text-gray-500 mb-2">{formattedDate}</time>
          <p className="text-gray-600 text-base leading-relaxed">{excerpt}</p>
        </div>
      </Link>
    </li>
  );
}

export default PostItem;
