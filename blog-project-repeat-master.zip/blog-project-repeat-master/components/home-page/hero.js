import Image from "next/image";

function Hero() {
  return (
    <section className="flex flex-col items-center justify-center text-center py-12 bg-gray-100">
      <div className="w-48 h-48 rounded-full overflow-hidden border-4 border-blue-500 mb-6">
        <Image
          src="/images/site/max.png"
          alt="An image showing Max"
          width={300}
          height={300}
          className="object-cover w-full h-full"
        />
      </div>
      <h1 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
        Hi, I’m Max
      </h1>
      <p className="text-gray-600 max-w-xl px-4">
        I blog about web development — especially frontend frameworks like React
        or Angular.
      </p>
    </section>
  );
}

export default Hero;
