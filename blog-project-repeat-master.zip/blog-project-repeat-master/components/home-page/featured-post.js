//import PostsGrid from "../posts/posts-grid";

import PostsGrid from "../posts/posts-grid";

function FeaturedPosts(props){
    return <section>
        <h2>Featured posts</h2>
        <PostsGrid posts={props.posts}/>
    </section>

}
export default FeaturedPosts;