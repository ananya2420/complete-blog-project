import PostsGrid from './posts-grid';

function AllPosts({ posts }) {
  return <PostsGrid posts={posts} />;
}

export default AllPosts;
