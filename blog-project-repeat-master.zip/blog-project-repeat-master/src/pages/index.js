import { Fragment } from "react";
import Hero from "../../components/home-page/hero";
import FeaturedPosts from "../../components/home-page/featured-post";
import { getFeaturedPost } from "../../lib/posts.util";


const DUMMY_POSTS=[

  {
    slug:'getting-started-with-nextjs',
    title:'getting started with nextjs',
    image:'getting-started-nextjs.png',
    excerpt:'NextJs is the react framework for production - it makes bulid fullstack React apps and sites a breeze and ships with bulid in -SSR',
    date:'2022-02-10'
    
  },
  {
    slug:'getting-started-with-nextjs2',
    title:'getting started with nextjs',
    image:'getting-started-nextjs.png',
    excerpt:'NextJs is the react framework for production - it makes bulid fullstack React apps and sites a breeze and ships with bulid in -SSR',
    date:'2022-02-10'
    
  },
  {
    slug:'getting-started-with-nextjs3',
    title:'getting started with nextjs',
    image:'getting-started-nextjs.png',
    excerpt:'NextJs is the react framework for production - it makes bulid fullstack React apps and sites a breeze and ships with bulid in -SSR',
    date:'2022-02-10'
    
  },
  {
    slug:'getting-started-with-nextjs4',
    title:'getting started with nextjs',
    image:'getting-started-nextjs.png',
    excerpt:'NextJs is the react framework for production - it makes bulid fullstack React apps and sites a breeze and ships with bulid in -SSR',
    date:'2022-02-10'
    
  }
];

function HomePage(props) {
  return (
    <Fragment>
      <Hero />
      <FeaturedPosts posts={props.posts}/>
    </Fragment>
  );
}
export function getStaticProps(){
  const featuredPosts = getFeaturedPost();

  return{
    props:{
      posts:featuredPosts
    },
    revalidate: 60
  }
}

export default HomePage;