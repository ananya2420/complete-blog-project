import Link from "next/link";
import Logo from "./logo";

function MainNavigation() {
  return (
    <header className="bg-white shadow-md px-6 py-4 flex items-center justify-between">
      <Link href="/" className="text-2xl font-bold text-blue-600 hover:text-blue-800">
        <Logo />
      </Link>

      <nav>
        <ul className="flex gap-6 text-gray-700 font-medium">
          <li>
            <Link href="/posts" className="hover:text-blue-600 transition-colors">
              Posts
            </Link>
          </li>
          <li>
            <Link href="/contact" className="hover:text-blue-600 transition-colors">
              Contacts
            </Link>
          </li>
        </ul>
      </nav>
    </header>
  );
}

export default MainNavigation;
