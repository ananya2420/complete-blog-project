import PostItem from "./posts-item";

const DUMMY_POSTS = [
  {
    slug: "getting-started-with-nextjs",
    title: "Getting Started with Next.js",
    image: "getting-started-nextjs.png",
    excerpt:
      "Next.js is the React framework for production - it makes building fullstack React apps and sites a breeze and ships with built-in SSR.",
    date: "2022-02-10",
  },
  {
    slug:'getting-started-with-nextjs2',
    title:'getting started with nextjs',
    image:'getting-started-nextjs.png',
    excerpt:'NextJs is the react framework for production - it makes bulid fullstack React apps and sites a breeze and ships with bulid in -SSR',
    date:'2022-02-10'
    
  },
  {
    slug:'getting-started-with-nextjs3',
    title:'getting started with nextjs',
    image:'getting-started-nextjs.png',
    excerpt:'NextJs is the react framework for production - it makes bulid fullstack React apps and sites a breeze and ships with bulid in -SSR',
    date:'2022-02-10'
    
  },
  {
    slug:'getting-started-with-nextjs4',
    title:'getting started with nextjs',
    image:'getting-started-nextjs.png',
    excerpt:'NextJs is the react framework for production - it makes bulid fullstack React apps and sites a breeze and ships with bulid in -SSR',
    date:'2022-02-10'
    
  }
];

function PostsGrid(props) {
  const posts = props.posts || DUMMY_POSTS;

  return (
    <ul className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {posts.map((post) => (
        <PostItem key={post.slug} post={post} />
      ))}
    </ul>
  );
}

export default PostsGrid;
