---
title: "Mastering JavaScript"
excerpt: "JavaScript is the most important programming language for web development. You probably don't know it very well!"
image: "mastering-js-thumb.png"
isFeatured: false
date: "2021-10-30"
---

JavaScript powers the web — it's **the** most important programming language you need to know as a web developer.

For example, we should understand code like this:

```js
const basics = "Okay, that should not be too difficult actually.";

function printBasics() {
  console.log(basics);
}
