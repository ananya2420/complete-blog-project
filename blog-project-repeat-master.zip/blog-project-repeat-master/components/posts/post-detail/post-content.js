import Image from "next/image";
import PostHeader from "./post-header";
import ReactMarkdown from 'react-markdown';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { atomDark } from 'react-syntax-highlighter/dist/cjs/styles/prism';

function PostContent(props) {
  const { post } = props;

  const imagePath = `/images/posts/${post.image}`;

  const customRenders = {
    paragraph(paragraph) {
      const { node } = paragraph;

      if (node.children[0]?.type === 'image') {
        const image = node.children[0];
        return (
          <div className="my-6">
            <Image
              src={`/images/posts/${post.slug}/${image.url}`}
              alt={image.alt}
              width={600}
              height={300}
            />
          </div>
        );
      }

      return <p>{paragraph.children}</p>;
    },

    code({ node, inline, className, children, ...props }) {
      const match = /language-(\w+)/.exec(className || '');
      return !inline && match ? (
        <SyntaxHighlighter
          style={atomDark}
          language={match[1]}
          PreTag="div"
          className="rounded-lg my-4"
          {...props}
        >
          {String(children).replace(/\n$/, '')}
        </SyntaxHighlighter>
      ) : (
        <code className="bg-gray-200 text-sm px-1 rounded">
          {children}
        </code>
      );
    }
  };

  return (
    <article className="prose lg:prose-xl mx-auto my-12 px-4">
      <PostHeader title={post.title} image={imagePath} />
      <div className="mt-6 text-gray-700 whitespace-pre-line">
        <ReactMarkdown components={customRenders}>
          {post.content}
        </ReactMarkdown>
      </div>
    </article>
  );
}

export default PostContent;
