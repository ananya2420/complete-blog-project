function Logo(){
    return <div>
        Max Next blog
    </div>

}
export default Logo;