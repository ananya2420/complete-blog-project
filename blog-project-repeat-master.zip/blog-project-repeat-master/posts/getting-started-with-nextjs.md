---
title: 'Getting Started with Next.js'
date: '2022-10-15'
image: 'getting-started-nextjs.png'
excerpt: 'Next.js is the React framework for production - it makes building fullstack React apps and sites a breeze and ships with built-in SSR.'
isFeatured: true
---

NextJs is a **framework for reactJS**

wait a second  ... a "framework" for React? Isn't react itself already a framework for Javascript?

well ... first of all, react is a "library" for javascript.. That seem to be important for some people.

Not for me,  but still,  there is a valid point: react alread is a framework / library for javascript.

## Why would we need NextJS?

Becaue nextjs app creates react apps easier-specially React apps that sould have server side rendering.(though it does wa moe than just take care of that).

In this article we will dive into the core concepts and Nextjs feature has to offer:

-File based routing
-Bulit-in page pre-rendering
-Rich data fetching capabilities
-Image optimization
-Much more

## File based routing?

![create routes via your file + folder structure](/images/posts/nextjs-file-based-routing.png)

...More content...
