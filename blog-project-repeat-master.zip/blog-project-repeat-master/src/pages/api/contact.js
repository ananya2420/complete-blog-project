import { MongoClient } from 'mongodb';

async function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).json({ message: 'Method Not Allowed' });
    return;
  }

  const { email, name, message } = req.body;

  // Validate input
  if (
    !email ||
    !email.includes('@') ||
    !name ||
    name.trim() === '' ||
    !message ||
    message.trim() === ''
  ) {
    res.status(422).json({ message: 'Invalid input.' });
    return;
  }

  const newMessage = {
    email,
    name,
    message,
  };

  let client;

  try {
    client = await MongoClient.connect(
      'mongodb+srv://greatstack:JULzGXURFSCgr5JR@cluster0.mwhfzre.mongodb.net/my-site?retryWrites=true&w=majority&appName=Cluster0'
    );
  } catch (error) {
    console.error('Database connection failed:', error);
    res.status(500).json({ message: 'Could not connect to the database.' });
    return;
  }

  try {
    const db = client.db();
    const result = await db.collection('messages').insertOne(newMessage);
    newMessage.id = result.insertedId;
    res
      .status(200)
      .json({ message: 'Successfully stored message!', data: newMessage });
  } catch (error) {
    console.error('Storing message failed:', error);
    res.status(500).json({ message: 'Storing message failed!' });
  } finally {
    client.close();
  }
}

export default handler;
