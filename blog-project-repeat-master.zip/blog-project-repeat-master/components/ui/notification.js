function Notification(props) {
    const { title, message, status } = props;
  
    let bgColor = 'bg-gray-200';
    let textColor = 'text-black';
  
    if (status === 'success') {
      bgColor = 'bg-green-100';
      textColor = 'text-green-800';
    }
    if (status === 'error') {
      bgColor = 'bg-red-100';
      textColor = 'text-red-800';
    }
    if (status === 'pending') {
      bgColor = 'bg-yellow-100';
      textColor = 'text-yellow-800';
    }
  
    return (
      <div className={`p-4 rounded-md shadow-md mb-4 ${bgColor} ${textColor}`}>
        <h2 className="font-semibold text-lg mb-1">{title}</h2>
        <p>{message}</p>
      </div>
    );
  }
  
  export default Notification;
  